import setuptools

setuptools.setup(
    name="mgtwr",
    version="1.0.4",
    author="Kun Sun",
    author_email="849024477@qq.com",
    packages=['mgtwr']
    )
          
        
            
