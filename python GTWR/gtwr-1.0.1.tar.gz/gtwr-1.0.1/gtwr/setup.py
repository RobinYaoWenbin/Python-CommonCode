import setuptools

setuptools.setup(
    name="gtwr",
    version="1.0.1",
    long_description = 'To fit geographically and temporally weighted regression model',
    author="Kun Sun",
    author_email="849024477@qq.com",
    packages=['gtwr']
    )
          
        
            
